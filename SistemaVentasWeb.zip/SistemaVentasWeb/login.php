<?php

require_once "Database.php";

$nombre = $_POST["user"];
$pass = $_POST["pass"];

if($nombre == null || $pass == null)
{
    echo "<script>alert('Error, campos vacios')</script>";
    header("Refresh:0 , url = index.html");
    exit();
}
else
{
$query = mysqli_query($conn,"SELECT * FROM usuarios WHERE  usuario = '".$nombre."' AND clave = '".$pass."'");
$nr = mysqli_fetch_assoc($query);

if($nr == true)
{
    session_start();
    $_SESSION['user_info'] = array('p_nombre'=>$nr['p_nombre'],'p_apellido'=>$nr['p_apellido']);
    $_SESSION['rol'] = $nr['rol_id'];
    if(isset($_SESSION['rol'])){
        switch($_SESSION['rol']){
            case '1':
                echo "<script>window.open('panel/principal.php','_self',null,true)</script>";
            break;
            case '2':
                echo "<script>window.open('panel/clientes/cliente.php','_self',null,true)</script>";
            break;
        }   
    }   
    session_write_close();
}
else if ($nr == false)
{
    echo "<script>alert('Usuario o contraseña incorrecto')</script>";
    header("Refresh:0 , url = index.html");
    exit();
}
}
?>