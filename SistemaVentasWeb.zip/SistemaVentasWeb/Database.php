<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $dbname = "sistema_ventas";
    $conn = new mysqli($host , $user, $pass, $dbname);
    mysqli_query($conn , "SET character_set_result=utf8");
    if($conn->connect_error){
        die("No hay conexion: " . $conn->connect_error);
    }
?>