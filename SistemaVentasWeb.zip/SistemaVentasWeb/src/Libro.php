<?php

namespace Tienda;

class Libro{
    private $config;
    private $cn = null;

    public function __construct() 
    {
        $this -> config = parse_ini_file(__DIR__.'/../config.ini');

        $this->cn = new \PDO($this -> config['dns'], $this -> config['usuario'], $this -> config['clave'],array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
        ));
    }

    public function registrar($_parametro){
        $sql = "INSERT INTO `libros`(`titulo`, `descripcion`, `foto`, `precio`, `categoria_id`, `fecha`) VALUES (:titulo, :descripcion, :foto, :precio, :categoria_id, :fecha)";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":titulo" => $_parametro['titulo'],
            ":descripcion" => $_parametro['descripcion'],
            ":foto" => $_parametro['foto'],
            ":precio" => $_parametro['precio'],
            ":categoria_id" => $_parametro['categoria_id'],
            ":fecha" => $_parametro['fecha']
        );

        if ($resultado->execute($_array))
            return true;

        return false;
    }

    public function actualizar($_parametro){
        $sql = "UPDATE `libros` SET `titulo`=:titulo,`descripcion`=:descripcion,`foto`=:foto,`precio`=:precio,`categoria_id`=:categoria_id,`fecha`=:fecha WHERE `Id`=:Id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":titulo" => $_parametro['titulo'],
            ":descripcion" => $_parametro['descripcion'],
            ":foto" => $_parametro['foto'],
            ":precio" => $_parametro['precio'],
            ":categoria_id" => $_parametro['categoria_id'],
            ":fecha" => $_parametro['fecha'],
            ":Id" => $_parametro['Id']
        );

        if ($resultado->execute($_array))
            return true;

        return false;  
    }

    public function eliminar($id){
        $sql = "DELETE FROM `libros` WHERE `Id`=:Id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":Id" =>  $id
        );

        if ($resultado->execute($_array))
            return true;
 
        return false;
    }

    public function mostrar(){
        $sql = "SELECT libros.Id, titulo, descripcion, foto, nombre, precio, fecha, estado FROM libros

        INNER JOIN categorias
        ON libros.categoria_id = categorias.Id ORDER BY libros.titulo 
        ";

        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll(); //trae todos los registros

        return false;
    }

    public function mostrarPorId($id){
        $sql = "SELECT * FROM `libros` WHERE `Id`=:Id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":Id" =>  $id
        );

        if ($resultado->execute($_array))
            return $resultado->fetch();

        return false;
    } 

    public function mostrarPorNombre($titulo){
        $sql = "SELECT * FROM `libros` WHERE `titulo`=:titulo";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":titulo" =>  $titulo
        );

        if ($resultado->execute($_array))
            return $resultado->fetch();

        return false;
    }
}
?>