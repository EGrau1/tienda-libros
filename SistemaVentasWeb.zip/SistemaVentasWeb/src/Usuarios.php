<?php

namespace Tienda;

class Usuarios{
    private $config;
    private $cn = null;

    public function __construct() 
    {
        $this -> config = parse_ini_file(__DIR__.'/../config.ini');

        $this->cn = new \PDO($this -> config['dns'], $this -> config['usuario'], $this -> config['clave'],array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
        ));
    }
    public function registrar($_parametro){
        $sql = "INSERT INTO `usuarios`(`usuario`, `clave`, `p_nombre`, `s_nombre`, `p_apellido`, `s_apellido`, `rol_id`) VALUES (:usuario, :clave, :p_nombre, :s_nombre, :p_apellido, :s_apellido, :rol_id)";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":usuario" => $_parametro['usuario'],
            ":clave" => $_parametro['clave'],
            ":p_nombre" => $_parametro['p_nombre'],
            ":s_nombre" => $_parametro['s_nombre'],
            ":p_apellido" => $_parametro['p_apellido'],
            ":s_apellido" => $_parametro['s_apellido'],
            ":rol_id" => $_parametro['rol_id']
        );

        if ($resultado->execute($_array))
            return true;

        return false;
    }

    public function actualizar($_parametro){
        $sql = "UPDATE `usuarios` SET `usuario`=:usuario,`clave`=:clave,`p_nombre`=:p_nombre,`s_nombre`=:s_nombre,`p_apellido`=:p_apellido,`s_apellido`=:s_apellido,`rol_id`=:rol_id WHERE `Id`=:Id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":usuario" => $_parametro['usuario'],
            ":clave" => $_parametro['clave'],
            ":p_nombre" => $_parametro['p_nombre'],
            ":s_nombre" => $_parametro['s_nombre'],
            ":p_apellido" => $_parametro['p_apellido'],
            ":s_apellido" => $_parametro['s_apellido'],
            ":rol_id" => $_parametro['rol_id'],
            ":Id" => $_parametro['Id']
        );

        if ($resultado->execute($_array))
            return true;

        return false;  
    }

    public function eliminar($id){
        $sql = "DELETE FROM `usuarios` WHERE `Id`=:Id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":Id" =>  $id
        );

        if ($resultado->execute($_array))
            return true;
 
        return false;
    }

    public function mostrar(){
        $sql = "SELECT usuarios.Id, usuarios.p_nombre, usuarios.s_nombre, usuarios.p_apellido, usuarios.s_apellido, roles.rol
        FROM usuarios
        INNER JOIN roles ON usuarios.rol_id = roles.Id
        ";

        $resultado = $this->cn->prepare($sql);

        if ($resultado->execute())
            return $resultado->fetchAll(); //trae todos los registros

        return false;
    }

    public function mostrarPorId($id){
        $sql = "SELECT * FROM `usuarios` WHERE `Id`=:Id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":Id" =>  $id
        );

        if ($resultado->execute($_array))
            return $resultado->fetch();

        return false;
    } 
}
?>