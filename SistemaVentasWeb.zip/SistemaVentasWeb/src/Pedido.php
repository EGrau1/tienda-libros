<?php

namespace Tienda;

class Pedido{

    private $config;
    private $cn = null;

    public function __construct(){ 

        $this->config = parse_ini_file(__DIR__.'/../config.ini') ;

        $this->cn = new \PDO( $this->config['dns'], $this->config['usuario'],$this->config['clave'],array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'
        ));
    }

    public function registrar($_parametro){
        $sql = "INSERT INTO `pedidos`(`cliente_id`, `total`, `fecha`) 
        VALUES (:cliente_id,:total,:fecha)";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":cliente_id" => $_parametro['cliente_id'],
            ":total" => $_parametro['total'],
            ":fecha" => $_parametro['fecha'],
            
        );

        if($resultado->execute($_array))
            return $this->cn->lastInsertId();

        return false;
    }

    public function registrarDetalle($_parametro){
        $sql = "INSERT INTO `det_pedidos`(`pedido_id`, `libro_id`, `precio`, `cantidad`) 
        VALUES (:pedido_id,:libro_id,:precio,:cantidad)";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ":pedido_id" => $_parametro['pedido_id'],
            ":libro_id" => $_parametro['libro_id'],
            ":precio" => $_parametro['precio'],
            ":cantidad" => $_parametro['cantidad'],
        );

        if($resultado->execute($_array))
            return  true;

        return false;
    } 

    public function mostrar()
    {
        $sql = "SELECT p.Id, nombre, apellido, email, total, fecha FROM pedidos p 
        INNER JOIN clientes c ON p.cliente_id = c.Id ORDER BY p.Id DESC";

        $resultado = $this->cn->prepare($sql);

        if($resultado->execute())
            return  $resultado->fetchAll();

        return false;

    }

    public function mostrarUltimos()
    {
        $sql = "SELECT p.Id, nombre, apellido, email, total, fecha FROM pedidos p 
        INNER JOIN clientes c ON p.cliente_id = c.Id ORDER BY p.Id DESC LIMIT 10";

        $resultado = $this->cn->prepare($sql);

        if($resultado->execute())
            return  $resultado->fetchAll();

        return false;

    }

    public function mostrarPorId($id)
    {
        $sql = "SELECT p.Id, nombre, apellido, email, total, fecha FROM pedidos p 
        INNER JOIN clientes c ON p.cliente_id = c.Id WHERE p.Id = :Id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ':Id'=>$id
        );

        if($resultado->execute($_array ))
            return  $resultado->fetch();

        return false;
    }

    public function mostrarDetallePorIdPedido($id)
    {
        $sql = "SELECT 
                dp.Id,
                pe.titulo,
                dp.precio,
                dp.cantidad,
                pe.foto
                FROM det_pedidos dp
                INNER JOIN libros pe ON pe.Id= dp.libro_id
                WHERE dp.pedido_id = :Id";

        $resultado = $this->cn->prepare($sql);

        $_array = array(
            ':Id'=>$id
        );

        if($resultado->execute( $_array))
            return  $resultado->fetchAll();

        return false;
    }
}