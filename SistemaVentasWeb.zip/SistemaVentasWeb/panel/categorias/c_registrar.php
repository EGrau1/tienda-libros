<?php
session_start();

if(!isset($_SESSION['rol'])){
  header('location: ../../index.html');
}else{
  if($_SESSION['rol'] != "1"){
    header('location: ../../index.html');
  }
}
?>

<! DOCTYPE html >
<html>
<head>
  <title>INICIO </title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../../assets/css/estilos.css">
  <style>
    *{
    margin: 0px;
    padding: 0px;
    text-decoration: none;
  }
  
  #contenedor{
    width:calc(100% - 2px);
    margin-left:0px;
    margin-right:0px;
    float:left;
  }
  
  #cabecera{
    width: 97.65%;
    height: 35px;
    background: blue;
    color: white;
    text-align: start;
    font-size: 15px;
    font-family: arial;
    float: left;
    position: absolute;
    top: 0px;
    padding-top: 30px;
    padding-left: 30px;
  }
  
  #barraizquierda{
    width: 20%;
    background: black;
    min-height: 605px;
    color: white;
    float: left;
    word-wrap: break-word;
    margin-top: 60px;
    position:fixed;
    text-align: center;
  }

    #contenedor #barraizquierda ul li{
      display:inline-block;
      list-style-type: none;
    }
    
    #contenedor #barraizquierda ul li a{
      /*text-decoration: none;*/
      color: white;
      padding: 10px;
    }
    
    #contenedor #barraizquierda ul li a:hover{
      background: white;
      color: black;
    }
  
    #contenido{
    width: 80%;
    background: gray;
    min-height: 605px;
    float: left;
    word-wrap: break-word;
    margin-top: 60px;
    margin-left: 20%;
    position: fixed;
  }
  </style>
</head>
<body>
  <div id="contenedor">
    <div id="cabecera">
      <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
            </button>
            <a class="navbar-brand" href="../principal.php">Biblioteca Online</a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav pull-right">
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">admin <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="../../salir.php">Cerrar Sesión</a></li>
                </ul>
              </li> 
            </ul>
          </div><!--/.nav-collapse -->
        </div>
      </nav>
   </div>
    <div id="barraizquierda">
      <ul>
      </br></br></br><li><a href="../pedidos/pedido.php">PEDIDOS</a></li></br></br>
      </br></br><li><a href="../libros/libros.php">LIBROS</a></li></br></br>
      </br></br><li class="active"><a href="categorias.php">GENEROS</a></li></br></br>
      </br></br><li><a href="../usuarios/usuarios.php">USUARIOS </a></li></br></br>
      </br></br><li><a href="../roles/roles.php">ROLES</a></li></br></br>
      </ul>
    </div>
    <div id="contenido" class="container" style="overflow: scroll; color:white;">
</br>
     <div class="row">
        <div class="col-md-12">
          <fieldset>
            <legend style="font-weight:bold; color:white;">Generos</legend>
            <form method="POST" action="../control_c.php" enctype="multipart/form-data" > 
              <div class="row">
                  <div class="col-md-6">
                      <div class="form-group">
                          <label>Titulo</label>
                          <input type="text" class="form-control" name="nombre" autocomplete="off" autofocus required>
                      </div>
                  </div>
              </div>
              <input type="submit" name="accion" class="btn btn-primary" value="Registrar">
              <a href="categorias.php" class="btn btn-default">Cancelar</a>
            </form>
          </fieldset>
        </div>
      </div>
    </div>
  </div>
  <script src="../../assets/js/jquery.min.js"></script>
  <script src="../../assets/js/bootstrap.min.js"></script>
</body>
</html>