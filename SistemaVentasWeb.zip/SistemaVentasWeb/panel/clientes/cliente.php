<?php
session_start();
require 'funciones.php';
require_once "../../Database.php";

print_r($_SESSION['user_info']);

if(!isset($_SESSION['rol'])){
  header('location: ../../index.html');
}else{
  if($_SESSION['rol'] != "2"){
    header('location: ../../index.html');
  }
}
?>
<!DOCTYPE html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Books Center</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/estilos.css">
    <style>
    *{
    margin: 0px;
    padding: 0px;
    text-decoration: none;
  }
  #contenido{
 width: 100%;
 background: brown;
 height: 400%;
 color: white;
 font-size: 14px;
 font-family: arial;
 float: left;
 margin-top: 1px;
}
  </style>
  </head>

  <body style="background-image:url('../../img/fondo3.jpg')">
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
          </button>
          <img src="../../img/libro.jpg" width="50px" height="50px" style="margin-top: 8px;">
          <a class="navbar-brand" href="cliente.php">Books Center</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li>
              <a href="carrito.php" class="btn">CARRITO <span class="badge"><?php print cantidadLibro(); ?></span></a>
            </li>
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Cliente <span class="caret"></span></a>
                <ul class="dropdown-menu">
                   <li><a href="../../salir.php">Cerrar Sesión</a></li>
                </ul>
            </li>
          </ul>
          <form class="d-flex" method="GET" action="">
            <div class="btn-toolbar pull-right" style="margin-top: 15px;">
              <button class="btn btn-secondary btn-sm" type="submit" name="enviar">Buscar</button>
              <input style="width: 270px; height:35px" class="form-control me-2" name="buscar" aria-label="Search" autocomplete="off">
            </div>
          </form>
        </div>
     </div>
    </nav>
    <div class="container" id="main">
        <div class="row">

            <?php
              if(isset($_GET['enviar'])){
                $busqueda = $_GET['buscar'];
                $consulta = $conn->query("SELECT * FROM libros WHERE titulo LIKE '%$busqueda%'");
                while ($row = $consulta->fetch_array()){ 
                  if($row == true){ ?>
                  
                  <div class="col-md-3">
                    <div class="panel panel-default">
                      <div class="panel-heading">
                        <h1 class="text-center titulo-pelicula"><?php print $row['titulo'] ?></h1>  
                      </div>
                      <div class="panel-body">
                        <?php
                            $foto = '../../archivos/'.$row['foto'];
                            if(file_exists($foto)){
                          ?>
                          <img src="<?php print $foto; ?>" class="img-responsive">
                        <?php }else{?>
                        <img src="../../assets/imagenes/not-found.jpg" class="img-responsive">
                        <?php }?>
                      </div>
                      <div class="panel-footer">
                        <h5 class="text-center">Precio: <?php print $row['precio'] ?>Lps.</h5> 
                        <a href="carrito.php?Id=<?php print $row['Id'] ?>" class="btn btn-success btn-block">
                          <span class="glyphicon glyphicon-shopping-cart"></span> Comprar
                        </a>
                      </div>
                   </div>
                   <?php
                    }else{?>
                     <h4>NO HAY REGISTROS</h4>
                     <?php } ?>
                  </div>
            <?php
                }
              } else {
            ?>
            <?php
              require '../../vendor/autoload.php';
              $libro = new Tienda\Libro;
              $info_libro = $libro->mostrar();
              $cantidad = count($info_libro);
              if($cantidad > 0){
                for($x =0; $x < $cantidad; $x++){
                  $item = $info_libro[$x];
            ?>
              <div class="col-md-3">
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h1 class="text-center titulo-pelicula"><?php print $item['titulo'] ?></h1>  
                    </div>
                    <div class="panel-body">
                      <?php
                          $foto = '../../archivos/'.$item['foto'];
                          if(file_exists($foto)){
                        ?>
                          <img src="<?php print $foto; ?>" class="img-responsive">
                      <?php }else{?>
                        <img src="../../assets/imagenes/not-found.jpg" class="img-responsive">
                      <?php }?>
                    </div>
                    <div class="panel-footer">
                        <h5 class="text-center">Precio: <?php print $item['precio'] ?>Lps.</h5> 
                        <a href="carrito.php?Id=<?php print $item['Id'] ?>" class="btn btn-success btn-block">
                          <span class="glyphicon glyphicon-shopping-cart"></span> Comprar
                        </a>
                    </div>
                  </div>
              </div>
          <?php
                }
            }else{?>
              <h4>NO HAY REGISTROS</h4>
          <?php }
              }
          ?>
        </div>
      </div> 
    <script src="../../assets/js/jquery.min.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
  </body>
</html>
