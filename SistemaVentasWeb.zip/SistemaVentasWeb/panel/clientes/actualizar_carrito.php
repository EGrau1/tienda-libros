<?php

session_start();

if(!isset($_SESSION['rol'])){
    header('location: ../../index.html');
  }else{
    if($_SESSION['rol'] != "2"){
      header('location: ../../index.html');
    }
  }

if($_SERVER['REQUEST_METHOD'] ==='POST'){
    require 'funciones.php';
    $id = $_POST['Id'];
    $cantidad = $_POST['cantidad'];

    if(is_numeric($cantidad )){

        if(array_key_exists($id,$_SESSION['carrito']))
            actualizarLibro($id,$cantidad);
    }
  
    header('Location: carrito.php');
}
 