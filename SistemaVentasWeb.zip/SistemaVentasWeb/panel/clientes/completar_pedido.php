<?php

session_start();

if(!isset($_SESSION['rol'])){
    header('location: ../../index.html');
  }else{
    if($_SESSION['rol'] != "2"){
      header('location: ../../index.html');
    }
  }

if($_SERVER['REQUEST_METHOD'] ==='POST'){ //valida que la informacion recibida sea del metodo post

    require 'funciones.php';
    require '../../vendor/autoload.php';

    if(isset($_SESSION['carrito']) && !empty($_SESSION['carrito'])){
        $cliente = new Tienda\Cliente;
    
        $_parametro = array(
            'nombre' => $_POST['nombre'],
            'apellido' => $_POST['apellido'],
            'email' => $_POST['email'],
            'telefono' => $_POST['telefono'],
            'comentario' => $_POST['comentario']
        );
    
        $cliente_id = $cliente->registrar($_parametro);
    
        $pedido = new Tienda\Pedido;
    
        $_parametro = array(
            'cliente_id'=>$cliente_id,
            'total' => calcularTotal(),
            'fecha' => date('Y-m-d')
        );
        
        $pedido_id =  $pedido->registrar($_parametro);

        foreach($_SESSION['carrito'] as $indice => $value){
            $_parametro = array(
                "pedido_id" => $pedido_id,
                "libro_id" => $value['Id'],
                "precio" => $value['precio'],
                "cantidad" => $value['cantidad'],
            );

            $pedido->registrarDetalle($_parametro);
        }

        $_SESSION['carrito'] = array(); //Limpiar la sesion
        header('Location: gracias.php');
    }
}
?>