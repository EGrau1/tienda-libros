<?php
session_start();
require 'funciones.php';

if(!isset($_SESSION['rol'])){
  header('location: ../../index.html');
}else{
  if($_SESSION['rol'] != "2"){
    header('location: ../../index.html');
  }
}
?>
<!DOCTYPE html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Books Center</title>
    <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/css/estilos.css">
    <style>
    *{
    margin: 0px;
    padding: 0px;
    text-decoration: none;
  }
  #contenido{
 width: 100%;
 background: brown;
 height: 400%;
 color: white;
 font-size: 14px;
 font-family: arial;
 float: left;
 margin-top: 1px;
}
  </style>
  </head>
  <body style="background-image:url('../../img/fondo3.jpg')">
    <nav class="navbar navbar-default navbar-fixed-top">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
          </button>
          <img src="../../img/libro.jpg" width="50px" height="50px" style="margin-top: 8px;">
          <a class="navbar-brand" href="cliente.php">Books Center</a>
        </div>     
      </div>
      <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Cliente <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="../../salir.php">Cerrar Sesión</a></li>
                </ul>
             </li>   
          </ul>
        </div>
    </nav>

    <div class="container" id="main">
        <div class="row">
            <div class="jumbotron">
                <p>Gracias por su compra</p>
                <p>
                    <a href="cliente.php">Regresar</a>
                </p>
            </div>
        </div>
    </div> 
    <script src="../../assets/js/jquery.min.js"></script>
    <script src="../../assets/js/bootstrap.min.js"></script>
  </body>
</html>
