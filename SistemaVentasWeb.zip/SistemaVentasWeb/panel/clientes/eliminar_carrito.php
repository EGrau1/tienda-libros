<?php
session_start();

if(!isset($_SESSION['rol'])){
    header('location: ../../index.html');
  }else{
    if($_SESSION['rol'] != "2"){
      header('location: ../../index.html');
    }
  }

if(!isset($_GET['Id']) OR !is_numeric($_GET['Id']))
    header('Location: carrito.php');

$id = $_GET['Id'];

if(isset($_SESSION['carrito'])){
    unset($_SESSION['carrito'][$id]);   
    header('Location: carrito.php');
}else{
    header('Location: cliente.php');
}


