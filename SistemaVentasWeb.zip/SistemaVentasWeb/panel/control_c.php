<?php

require '../vendor/autoload.php';

$categ = new Tienda\Categoria; 

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    if($_POST['accion'] === 'Registrar'){

        if(empty($_POST['nombre']))
            exit('Ingrese categoria');
        
        $_parametro = array(
            'nombre'=> $_POST['nombre']
        );

        $rpt = $categ->registrar($_parametro);

        if($rpt)
            header('Location: categorias/categorias.php');
        else
            print 'Error al registrar la categoria';
    }

    if ($_POST['accion'] === 'Actualizar'){

        if(empty($_POST['nombre']))
        exit('Ingrese categoria');
    
        $_parametro = array(
           'nombre'=> $_POST['nombre'],
           'Id'=> $_POST['Id']
        );

        $rpt = $categ->actualizar($_parametro);

        if($rpt)
            header('Location: categorias/categorias.php');
        else
           print 'Error al actualizar el libro';
    }
}

if($_SERVER['REQUEST_METHOD'] ==='GET'){

    $id = $_GET['Id'];
    $rpt = $categ->eliminar($id);
    
    if($rpt)
        header('Location: categorias/categorias.php');
    else
        print 'Error al eliminar el libro';
}

?>