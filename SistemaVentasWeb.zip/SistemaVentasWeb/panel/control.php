<?php

require '../vendor/autoload.php';

$libro = new Tienda\Libro; 

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    if($_POST['accion'] === 'Registrar'){

        if(empty($_POST['titulo']))
            exit('Completar titulo');
        
        if(empty($_POST['descripcion']))
            exit('Completar descripcion');

        if(empty($_POST['categoria_id']))
            exit('Seleccionar una Categoria');

        if(!is_numeric($_POST['categoria_id']))
            exit('Seleccionar una Categoria válida');

        
        $_parametro = array(
            'titulo'=> $_POST['titulo'],
            'descripcion'=> $_POST['descripcion'],
            'foto'=> subir(),
            'precio'=> $_POST['precio'],
            'categoria_id'=> $_POST['categoria_id'],
            'fecha'=> date('Y-m-d')
        );

        $rpt = $libro->registrar($_parametro);

        if($rpt)
            header('Location: libros/libros.php');
        else
            print 'Error al registrar el libro';
    }

    if ($_POST['accion'] === 'Actualizar'){

        if(empty($_POST['titulo']))
            exit('Completar titulo');
    
        if(empty($_POST['descripcion']))
            exit('Completar descripcion');

        if(empty($_POST['categoria_id']))
            exit('Seleccionar una Categoria');

        if(!is_numeric($_POST['categoria_id']))
            exit('Seleccionar una Categoria válida');

    
        $_parametro = array(
           'titulo'=> $_POST['titulo'],
           'descripcion'=> $_POST['descripcion'],
           'precio'=> $_POST['precio'],
           'categoria_id'=> $_POST['categoria_id'],
           'fecha'=> date('Y-m-d'),
           'Id'=> $_POST['Id']
        );

        if(!empty($_POST['foto_temp']))
           $_parametro['foto'] = $_POST['foto_temp'];
    
        if(!empty($_FILES['foto']['name']))
           $_parametro['foto'] = subir();

        $rpt = $libro->actualizar($_parametro);

        if($rpt)
            header('Location: libros/libros.php');
        else
           print 'Error al actualizar el libro';
    }
}

if($_SERVER['REQUEST_METHOD'] ==='GET'){

    $id = $_GET['Id'];
    $rpt = $libro->eliminar($id);
    
    if($rpt)
        header('Location: libros/libros.php');
    else
        print 'Error al eliminar el libro';
}


function subir() {

    $carpeta = __DIR__.'/../archivos/';

    $archivo = $carpeta.$_FILES['foto']['name']; //el segundo es el atributo

    move_uploaded_file($_FILES['foto']['tmp_name'],$archivo);

    return $_FILES['foto']['name'];
}

?>