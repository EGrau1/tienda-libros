<?php

require '../vendor/autoload.php';

$user = new Tienda\Usuarios; 

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    if($_POST['accion'] === 'Registrar'){

        if(empty($_POST['usuario']))
            exit('Ingresar nombre de usuario');
        
        if(empty($_POST['clave']))
            exit('Ingresar contraseña');

        if(empty($_POST['p_nombre']))
            exit('Ingresar primer nombre');

        if(empty($_POST['s_nombre']))
            exit('Ingresar segundo nombre');
            
        if(empty($_POST['p_apellido']))
            exit('Ingresar primer apellido');

        if(empty($_POST['s_apellido']))
            exit('Ingresar segundo apellido');

        if(!is_numeric($_POST['rol_id']))
            exit('Seleccionar un rol valido');

        
        $_parametro = array(
            "usuario" => $_POST['usuario'],
            "clave" => $_POST['clave'],
            "p_nombre" => $_POST['p_nombre'],
            "s_nombre" => $_POST['s_nombre'],
            "p_apellido" => $_POST['p_apellido'],
            "s_apellido" => $_POST['s_apellido'],
            "rol_id" => $_POST['rol_id']
        );

        $rpt = $user->registrar($_parametro);

        if($rpt)
            header('Location: usuarios/usuarios.php');
        else
            print 'Error al registrar usuario';
    }

    if ($_POST['accion'] === 'Actualizar'){

        if(empty($_POST['usuario']))
            exit('Ingresar nombre de usuario');

        if(empty($_POST['p_nombre']))
            exit('Ingresar primer nombre');

        if(empty($_POST['s_nombre']))
            exit('Ingresar segundo nombre');
            
        if(empty($_POST['p_apellido']))
            exit('Ingresar primer apellido');

        if(empty($_POST['s_apellido']))
            exit('Ingresar segundo apellido');

        if(!is_numeric($_POST['rol_id']))
            exit('Seleccionar un rol valido');
    
        $_parametro = array(
            "usuario" => $_POST['usuario'],
            "p_nombre" => $_POST['p_nombre'],
            "s_nombre" => $_POST['s_nombre'],
            "p_apellido" => $_POST['p_apellido'],
            "s_apellido" => $_POST['s_apellido'],
            "rol_id" => $_POST['rol_id']
        );

        $rpt = $user->actualizar($_parametro);

        if($rpt)
           header('Location: usuarios/usuarios.php');
        else
           print 'Error al actualizar usuario';
    }
}

if($_SERVER['REQUEST_METHOD'] ==='GET'){

    $id = $_GET['Id'];
    $rpt = $user->eliminar($id);
    
    if($rpt)
        header('Location: usuarios/usuarios.php');
    else
        print 'Error al eliminar el libro';
}

?>