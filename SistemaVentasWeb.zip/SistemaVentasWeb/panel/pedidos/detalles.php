<?php
session_start();

if(!isset($_SESSION['rol'])){
  header('location: ../../index.html');
}else{
  if($_SESSION['rol'] != "1"){
    header('location: ../../index.html');
  }
}
?>

<! DOCTYPE html >
<html>
<head>
  <title>INICIO </title>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <link rel="stylesheet" href="../../assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="../../assets/css/estilos.css">
  <style>
    *{
    margin: 0px;
    padding: 0px;
    text-decoration: none;
  }
  
  #contenedor{
    width:calc(100% - 2px);
    margin-left:0px;
    margin-right:0px;
    float:left;
  }
  
  #cabecera{
    width: 97.65%;
    height: 35px;
    background: blue;
    color: white;
    text-align: start;
    font-size: 15px;
    font-family: arial;
    float: left;
    position: absolute;
    top: 0px;
    padding-top: 30px;
    padding-left: 30px;
  }
  
  #barraizquierda{
    width: 20%;
    background: black;
    min-height: 100%;
    color: white;
    float: left;
    word-wrap: break-word;
    margin-top: 60px;
    position:fixed;
    text-align: center;
  }

    #contenedor #barraizquierda ul li{
      display:inline-block;
      list-style-type: none;
    }
    
    #contenedor #barraizquierda ul li a{
      /*text-decoration: none;*/
      color: white;
      padding: 10px;
    }
    
    #contenedor #barraizquierda ul li a:hover{
      background: white;
      color: black;
    }
  
    #contenido{
    width: 80%;
    background: gray;
    height: 100%;
    float: left;
    word-wrap: break-word;
    margin-top: 60px;
    margin-left: 20%;
    position: fixed;
  }

  #contenedor #contenido table{
      text-align: center;
      background: #3D3E5B;
      color: white;
    }
  </style>
</head>
<body>
  <div id="contenedor">
    <div id="cabecera">
      <nav class="navbar navbar-default navbar-fixed-top">
        <div class="container">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
              <span class="sr-only">Toggle navigation</span>
            </button>
            <a class="navbar-brand" href="../principal.php">Biblioteca Online</a>
          </div>
          <div id="navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav pull-right">
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">admin <span class="caret"></span></a>
                <ul class="dropdown-menu">
                  <li><a href="../../salir.php">Cerrar Sesión</a></li>
                </ul>
              </li> 
            </ul>
          </div><!--/.nav-collapse -->
        </div>
      </nav>
    </div>
    <div id="barraizquierda">
      <ul>
      </br></br></br><li class="active"><a href="pedido.php">PEDIDOS</a></li></br></br>
      </br></br><li><a href="../libros/libros.php">LIBROS</a></li></br></br>
      </br></br><li><a href="../categorias/categorias.php">GENEROS</a></li></br></br>
      </br></br><li><a href="../usuarios/usuarios.php">USUARIOS </a></li></br></br>
      </br></br><li><a href="../roles/roles.php">ROLES</a></li></br></br>
      </ul>
    </div>
    <div id="contenido" class="container"  style="overflow: scroll;">
    <div class="row">
     </br>
          <div class="col-md-12">
            <fieldset style="color:white;">
                <?php
                    require '../../vendor/autoload.php';
                    $id = $_GET['Id'];
                    $pedido = new Tienda\Pedido;
                    $info_pedido = $pedido->mostrarPorId($id);
                    $info_detalle_pedido = $pedido->mostrarDetallePorIdPedido($id);
                ?>                
                <legend style="font-weight:bold; color:white;">Información de la Compra</legend>
                <div class="form-group">
                    <label>Nombre</label>
                    <input value="<?php print $info_pedido['nombre'] ?>" type="text" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label>Apellido</label>
                    <input value="<?php print $info_pedido['apellido'] ?>" type="text" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input value="<?php print $info_pedido['email'] ?>" type="text" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label>Fecha</label>
                    <input value="<?php print $info_pedido['fecha'] ?>" type="text" class="form-control" readonly>
                </div>
               
                <hr>Productos Comprados</hr>
                <table class="table table-bordered" style="color:white;">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Titulo</th>
                      <th>Foto</th>
                      <th>Precio</th>
                      <th>Cantidad</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody> 
                    <?php                                       
                      $cantidad = count($info_detalle_pedido);
                      if($cantidad > 0){
                        $c=0;
                      for($x =0; $x < $cantidad; $x++){
                        $c++;
                        $item = $info_detalle_pedido[$x];
                        $total = $item['precio'] * $item['cantidad'];
                    ?>
                    <tr>
                      <td><?php print $c?></td>
                      <td><?php print $item['titulo']?></td>
                      <td>
                      <?php
                          $foto = '../../archivos/'.$item['foto'];
                          if(file_exists($foto)){
                        ?>
                          <img src="<?php print $foto; ?>" width="35">
                      <?php }else{?>
                          SIN FOTO
                      <?php }?>
                      </td>
                      <td><?php print $item['precio']?> Lps.</td>
                      <td><?php print $item['cantidad']?></td>
                    <td>
                    <?php print $total?>
                    </td>
                    </tr>
                    <?php
                      }
                    }else{
                    ?>
                    <tr>
                      <td colspan="6">NO HAY REGISTROS</td>
                    </tr>
                    <?php }?>                  
                  </tbody>
                </table>
                <div class="col-md-3">
                    <div class="form-group">
                        <label>Total Compra</label>
                        <input value="<?php print $info_pedido['total'] ?>" type="text" class="form-control" readonly>
                    </div>
                </div>                
            </fieldset>
            <div class="pull-left">
                <a href="pedido.php" class="btn btn-default hidden-print">Cancelar</a>
            </div>
            <div class="pull-right">
                <a href="javascript:;" id="btnImprimir" class="btn btn-danger hidden-print">Imprimir</a>
            </div>       
          </div>
        </div>
        </br></br></br>
      </div>
    </div>
  <script src="../../assets/js/jquery.min.js"></script>
  <script src="../../assets/js/bootstrap.min.js"></script>
  <script>
        $('#btnImprimir').on('click',function(){
          let newstr = document.getElementById("contenido").innerHTML;
          let oldstr = document.body.innerHTML;
          document.body.innerHTML = newstr;
          window.print();
          document.body.innerHTML = oldstr;
          return false;
        })                        
  </script>
</body>
</html>