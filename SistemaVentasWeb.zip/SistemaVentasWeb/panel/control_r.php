<?php

require '../vendor/autoload.php';

$roles = new Tienda\Roles; 

if($_SERVER['REQUEST_METHOD'] === 'POST'){

    if($_POST['accion'] === 'Registrar'){

        if(empty($_POST['rol']))
            exit('Ingrese nombre del rol');
        
        $_parametro = array(
            'rol'=> $_POST['rol']
        );

        $rpt = $roles->registrar($_parametro);

        if($rpt)
            header('Location: roles/roles.php');
        else
            print 'Error al registrar';
    }

    if ($_POST['accion'] === 'Actualizar'){

        if(empty($_POST['rol']))
        exit('Ingrese nombre del rol');
    
        $_parametro = array(
           'rol'=> $_POST['rol'],
           'Id'=> $_POST['Id']
        );

        $rpt = $categ->actualizar($_parametro);

        if($rpt)
           header('Location: roles/roles.php');
        else
           print 'Error al actualizar el libro';
    }
}

if($_SERVER['REQUEST_METHOD'] ==='GET'){

    $id = $_GET['Id'];
    $rpt = $categ->eliminar($id);
    
    if($rpt)
        header('Location: roles/roles.php');
    else
        print 'Error al eliminar el libro';
}

?>