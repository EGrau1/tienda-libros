<?php

require_once "Database.php";

$P_nombre = $_POST["P_nombre"];
$S_nombre = $_POST["S_nombre"];
$P_apellido = $_POST["P_apellido"];
$S_apellido = $_POST["S_apellido"];
$usuario = $_POST["user"];
$pass = $_POST["pass"];

if($P_nombre == null ||$S_nombre == null ||$P_apellido == null ||$S_apellido == null ||$usuario == null || $pass == null)
{
    echo "<script>alert('Error, campos vacios')</script>";
    header("Refresh:0 , url = index.html");
    exit();
}
else
{
$query = mysqli_query($conn,"INSERT INTO usuarios (`usuario`, `clave`, `p_nombre`, `s_nombre`, `p_apellido`, `s_apellido`, `rol_id`) VALUES ('".$usuario."','".$pass."','".$P_nombre."','".$S_nombre."','".$P_apellido."','".$S_apellido."','2')");

    echo "<script>alert('Registrado con exito')</script>";
    header("Refresh:0 , url = index.html");
    exit();
}
?>